

<?php $__env->startSection('title', 'Riwayat Pesanan - Al Afghani Juice'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
    <div>
        <h1 class="text-3xl font-bold text-gray-800">Riwayat Pesanan</h1>
        <p class="text-gray-600">Pantau pendapatan, pesanan yang menunggu arsip, dan riwayat berdasarkan tanggal.</p>
    </div>
    <a href="<?php echo e(route('cashier.dashboard')); ?>" class="inline-flex items-center gap-2 self-start rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
    </a>
</div>

<div class="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
    <div class="rounded-xl bg-white p-5 shadow-md">
        <p class="text-sm text-gray-500">Jumlah Pesanan Diarsipkan</p>
        <p class="text-2xl font-bold text-gray-800"><?php echo e(number_format($orders->total(), 0, ',', '.')); ?> pesanan</p>
    </div>
    <div class="rounded-xl bg-white p-5 shadow-md">
        <p class="text-sm text-gray-500">Total Pendapatan Pesanan Selesai</p>
        <p class="text-2xl font-bold text-gray-800">Rp <?php echo e(number_format($completedRevenue, 0, ',', '.')); ?></p>
    </div>
    <div class="rounded-xl bg-yellow-50 p-5 shadow-md">
        <p class="text-sm text-yellow-800">Selesai, Menunggu Arsip (&lt;24 Jam)</p>
        <p class="text-2xl font-bold text-yellow-900"><?php echo e(number_format($recentCompletedCount, 0, ',', '.')); ?> pesanan</p>
        <p class="mt-1 text-sm font-semibold text-yellow-800">Rp <?php echo e(number_format($recentCompletedRevenue, 0, ',', '.')); ?></p>
    </div>
</div>

<form method="GET" action="<?php echo e(route('cashier.orders.history')); ?>" class="mb-6 rounded-xl bg-white p-5 shadow-md">
    <div class="grid grid-cols-1 items-end gap-4 sm:grid-cols-3">
        <label class="text-sm font-medium text-gray-700">
            Dari tanggal
            <input type="date" name="date_from" value="<?php echo e($filters['date_from'] ?? ''); ?>" class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
        </label>
        <label class="text-sm font-medium text-gray-700">
            Sampai tanggal
            <input type="date" name="date_to" value="<?php echo e($filters['date_to'] ?? ''); ?>" class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
        </label>
        <div class="flex gap-2">
            <button type="submit" class="rounded-lg bg-green-600 px-4 py-2 font-semibold text-white hover:bg-green-700">
                <i class="fas fa-filter mr-1"></i> Filter
            </button>
            <a href="<?php echo e(route('cashier.orders.history')); ?>" class="rounded-lg border border-gray-300 px-4 py-2 font-semibold text-gray-700 hover:bg-gray-50">Reset</a>
        </div>
    </div>
    <?php if($errors->any()): ?>
        <p class="mt-3 text-sm text-red-600"><?php echo e($errors->first()); ?></p>
    <?php endif; ?>
</form>

<?php if($recentCompletedOrders->isNotEmpty()): ?>
    <div class="mb-6 overflow-hidden rounded-xl border border-yellow-200 bg-yellow-50 shadow-md">
        <div class="border-b border-yellow-200 px-5 py-4">
            <h2 class="font-bold text-yellow-900">Pesanan Selesai, Menunggu Arsip 24 Jam</h2>
            <p class="mt-1 text-sm text-yellow-800">Pendapatannya sudah dihitung. Pesanan ini akan masuk ke tabel riwayat setelah 24 jam.</p>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-gray-700">
                <thead class="text-xs uppercase tracking-wide text-yellow-900">
                    <tr>
                        <th class="px-5 py-3">Nomor Pesanan</th>
                        <th class="px-5 py-3">Pelanggan</th>
                        <th class="px-5 py-3">Waktu Selesai</th>
                        <th class="px-5 py-3 text-right">Total</th>
                        <?php if(auth()->user()->role !== 'analyst'): ?>
                            <th class="px-5 py-3 text-right">Detail</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-yellow-200">
                    <?php $__currentLoopData = $recentCompletedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="whitespace-nowrap px-5 py-3 font-semibold"><?php echo e($order->order_number); ?></td>
                            <td class="px-5 py-3"><?php echo e($order->customer_name ?? $order->user?->name ?? 'Pelanggan'); ?></td>
                            <td class="whitespace-nowrap px-5 py-3"><?php echo e($order->completed_at->format('d/m/Y H:i')); ?></td>
                            <td class="whitespace-nowrap px-5 py-3 text-right font-semibold">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
                            <?php if(auth()->user()->role !== 'analyst'): ?>
                                <td class="px-5 py-3 text-right">
                                    <a href="<?php echo e(route('cashier.orders.show', $order)); ?>" class="font-semibold text-green-700 hover:text-green-900">Lihat</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php if($recentCompletedCount > $recentCompletedOrders->count()): ?>
            <p class="border-t border-yellow-200 px-5 py-3 text-sm text-yellow-800">
                Menampilkan 10 pesanan terbaru dari <?php echo e(number_format($recentCompletedCount, 0, ',', '.')); ?> pesanan yang menunggu arsip.
            </p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="overflow-hidden rounded-xl bg-white shadow-md">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
                <tr>
                    <th class="px-5 py-4">Nomor Pesanan</th>
                    <th class="px-5 py-4">Pelanggan</th>
                    <th class="px-5 py-4">Tanggal Pesanan</th>
                    <th class="px-5 py-4">Tanggal Selesai</th>
                    <th class="px-5 py-4">Status</th>
                    <th class="px-5 py-4 text-right">Total</th>
                    <?php if(auth()->user()->role !== 'analyst'): ?>
                        <th class="px-5 py-4 text-right">Detail</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 text-sm text-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="whitespace-nowrap px-5 py-4 font-semibold"><?php echo e($order->order_number); ?></td>
                        <td class="px-5 py-4"><?php echo e($order->customer_name ?? $order->user?->name ?? 'Pelanggan'); ?></td>
                        <td class="whitespace-nowrap px-5 py-4"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                        <td class="whitespace-nowrap px-5 py-4"><?php echo e($order->completed_at?->format('d/m/Y H:i') ?? '-'); ?></td>
                        <td class="px-5 py-4">
                            <?php if($order->status === 'completed'): ?>
                                <span class="rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">Selesai</span>
                            <?php else: ?>
                                <span class="rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-700">Dibatalkan</span>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-5 py-4 text-right font-semibold">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
                        <?php if(auth()->user()->role !== 'analyst'): ?>
                            <td class="px-5 py-4 text-right">
                                <a href="<?php echo e(route('cashier.orders.show', $order)); ?>" class="font-semibold text-green-700 hover:text-green-900">Lihat</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(auth()->user()->role === 'analyst' ? 6 : 7); ?>" class="px-5 py-12 text-center text-gray-500">
                            <i class="fas fa-clock mb-2 block text-3xl text-gray-300"></i>
                            Belum ada riwayat pesanan untuk rentang tanggal ini.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($orders->hasPages()): ?>
        <div class="border-t border-gray-100 px-5 py-4"><?php echo e($orders->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\Kedai_Juice\resources\views/cashier/orders/history.blade.php ENDPATH**/ ?>